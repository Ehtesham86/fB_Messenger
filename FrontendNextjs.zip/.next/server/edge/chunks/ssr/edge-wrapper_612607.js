(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/ssr/edge-wrapper_612607.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/ssr/edge-wrapper_612607.js",
  "chunks": [
    "chunks/ssr/_b38c68._.js",
    "chunks/ssr/_4cf24e._.js"
  ],
  "source": "entry"
});
