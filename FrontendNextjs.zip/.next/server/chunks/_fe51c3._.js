module.exports = {

"[project]/utils/helpers.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "calculateTrialEndUnixTimestamp": ()=>calculateTrialEndUnixTimestamp,
    "getErrorRedirect": ()=>getErrorRedirect,
    "getStatusRedirect": ()=>getStatusRedirect,
    "getURL": ()=>getURL,
    "postData": ()=>postData,
    "toDateTime": ()=>toDateTime
});
const getURL = (path = '')=>{
    // Check if NEXT_PUBLIC_SITE_URL is set and non-empty. Set this to your site URL in production env.
    let url = process?.env?.NEXT_PUBLIC_SITE_URL && ("TURBOPACK compile-time value", "http://localhost:3000").trim() !== '' ? ("TURBOPACK compile-time value", "http://localhost:3000") : process?.env?.NEXT_PUBLIC_VERCEL_URL && process.env.NEXT_PUBLIC_VERCEL_URL.trim() !== '' ? process.env.NEXT_PUBLIC_VERCEL_URL : 'http://localhost:3000/';
    // Trim the URL and remove trailing slash if exists.
    url = url.replace(/\/+$/, '');
    // Make sure to include `https://` when not localhost.
    url = url.includes('http') ? url : `https://${url}`;
    // Ensure path starts without a slash to avoid double slashes in the final URL.
    path = path.replace(/^\/+/, '');
    // Concatenate the URL and the path.
    return path ? `${url}/${path}` : url;
};
const postData = async ({ url, data })=>{
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        credentials: 'same-origin',
        body: JSON.stringify(data)
    });
    return res.json();
};
const toDateTime = (secs)=>{
    var t = new Date(+0); // Unix epoch start.
    t.setSeconds(secs);
    return t;
};
const calculateTrialEndUnixTimestamp = (trialPeriodDays)=>{
    // Check if trialPeriodDays is null, undefined, or less than 2 days
    if (trialPeriodDays === null || trialPeriodDays === undefined || trialPeriodDays < 2) {
        return undefined;
    }
    const currentDate = new Date(); // Current date and time
    const trialEnd = new Date(currentDate.getTime() + (trialPeriodDays + 1) * 24 * 60 * 60 * 1000); // Add trial days
    return Math.floor(trialEnd.getTime() / 1000); // Convert to Unix timestamp in seconds
};
const toastKeyMap = {
    status: [
        'status',
        'status_description'
    ],
    error: [
        'error',
        'error_description'
    ]
};
const getToastRedirect = (path, toastType, toastName, toastDescription = '', disableButton = false, arbitraryParams = '')=>{
    const [nameKey, descriptionKey] = toastKeyMap[toastType];
    let redirectPath = `${path}?${nameKey}=${encodeURIComponent(toastName)}`;
    if (toastDescription) {
        redirectPath += `&${descriptionKey}=${encodeURIComponent(toastDescription)}`;
    }
    if (disableButton) {
        redirectPath += `&disable_button=true`;
    }
    if (arbitraryParams) {
        redirectPath += `&${arbitraryParams}`;
    }
    return redirectPath;
};
const getStatusRedirect = (path, statusName, statusDescription = '', disableButton = false, arbitraryParams = '')=>getToastRedirect(path, 'status', statusName, statusDescription, disableButton, arbitraryParams);
const getErrorRedirect = (path, errorName, errorDescription = '', disableButton = false, arbitraryParams = '')=>getToastRedirect(path, 'error', errorName, errorDescription, disableButton, arbitraryParams);

})()),
"[project]/utils/stripe/config.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "stripe": ()=>stripe
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stripe$2f$esm$2f$stripe$2e$esm$2e$node$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/stripe/esm/stripe.esm.node.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const stripe = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stripe$2f$esm$2f$stripe$2e$esm$2e$node$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"](process.env.STRIPE_SECRET_KEY_LIVE ?? process.env.STRIPE_SECRET_KEY ?? '', {
    // https://github.com/stripe/stripe-node#configuration
    // https://stripe.com/docs/api/versioning
    // @ts-ignore
    apiVersion: null,
    // Register this as an official Stripe plugin.
    // https://stripe.com/docs/building-plugins#setappinfo
    appInfo: {
        name: 'Next.js Subscription Starter',
        version: '0.0.0',
        url: 'https://github.com/vercel/nextjs-subscription-payments'
    }
});

})()),
"[project]/utils/supabase/admin.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "createOrRetrieveCustomer": ()=>createOrRetrieveCustomer,
    "deletePriceRecord": ()=>deletePriceRecord,
    "deleteProductRecord": ()=>deleteProductRecord,
    "manageSubscriptionStatusChange": ()=>manageSubscriptionStatusChange,
    "upsertPriceRecord": ()=>upsertPriceRecord,
    "upsertProductRecord": ()=>upsertProductRecord
});
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/utils/helpers.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/utils/stripe/config.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
// Change to control trial period length
const TRIAL_PERIOD_DAYS = 0;
// Note: supabaseAdmin uses the SERVICE_ROLE_KEY which you must only use in a secure server-side context
// as it has admin privileges and overwrites RLS policies!
const supabaseAdmin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(("TURBOPACK compile-time value", "https://wbvdunlrjeamezmqgezv.supabase.co") || '', process.env.SUPABASE_SERVICE_ROLE_KEY || '');
console.log(supabaseAdmin, '+++++++');
const upsertProductRecord = async (product)=>{
    const productData = {
        id: product.id,
        active: product.active,
        name: product.name,
        description: product.description ?? null,
        image: product.images?.[0] ?? null,
        metadata: product.metadata
    };
    const { error: upsertError } = await supabaseAdmin.from('products').upsert([
        productData
    ]);
    if (upsertError) throw new Error(`Product insert/update failed: ${upsertError.message}`);
    console.log(`Product inserted/updated: ${product.id}`);
};
const upsertPriceRecord = async (price, retryCount = 0, maxRetries = 3)=>{
    const priceData = {
        id: price.id,
        product_id: typeof price.product === 'string' ? price.product : '',
        active: price.active,
        currency: price.currency,
        type: price.type,
        unit_amount: price.unit_amount ?? null,
        interval: price.recurring?.interval ?? null,
        interval_count: price.recurring?.interval_count ?? null,
        trial_period_days: price.recurring?.trial_period_days ?? TRIAL_PERIOD_DAYS
    };
    const { error: upsertError } = await supabaseAdmin.from('prices').upsert([
        priceData
    ]);
    if (upsertError?.message.includes('foreign key constraint')) {
        if (retryCount < maxRetries) {
            console.log(`Retry attempt ${retryCount + 1} for price ID: ${price.id}`);
            await new Promise((resolve)=>setTimeout(resolve, 2000));
            await upsertPriceRecord(price, retryCount + 1, maxRetries);
        } else {
            throw new Error(`Price insert/update failed after ${maxRetries} retries: ${upsertError.message}`);
        }
    } else if (upsertError) {
        throw new Error(`Price insert/update failed: ${upsertError.message}`);
    } else {
        console.log(`Price inserted/updated: ${price.id}`);
    }
};
const deleteProductRecord = async (product)=>{
    const { error: deletionError } = await supabaseAdmin.from('products').delete().eq('id', product.id);
    if (deletionError) throw new Error(`Product deletion failed: ${deletionError.message}`);
    console.log(`Product deleted: ${product.id}`);
};
const deletePriceRecord = async (price)=>{
    const { error: deletionError } = await supabaseAdmin.from('prices').delete().eq('id', price.id);
    if (deletionError) throw new Error(`Price deletion failed: ${deletionError.message}`);
    console.log(`Price deleted: ${price.id}`);
};
const upsertCustomerToSupabase = async (uuid, customerId)=>{
    const { error: upsertError } = await supabaseAdmin.from('customers').upsert([
        {
            id: uuid,
            stripe_customer_id: customerId
        }
    ]);
    if (upsertError) throw new Error(`Supabase customer record creation failed: ${upsertError.message}`);
    return customerId;
};
const createCustomerInStripe = async (uuid, email)=>{
    const customerData = {
        metadata: {
            supabaseUUID: uuid
        },
        email: email
    };
    const newCustomer = await __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stripe"].customers.create(customerData);
    if (!newCustomer) throw new Error('Stripe customer creation failed.');
    return newCustomer.id;
};
const createOrRetrieveCustomer = async ({ email, uuid })=>{
    // Check if the customer already exists in Supabase
    const { data: existingSupabaseCustomer, error: queryError } = await supabaseAdmin.from('customers').select('*').eq('id', uuid).maybeSingle();
    if (queryError) {
        throw new Error(`Supabase customer lookup failed: ${queryError.message}`);
    }
    // Retrieve the Stripe customer ID using the Supabase customer ID, with email fallback
    let stripeCustomerId;
    if (existingSupabaseCustomer?.stripe_customer_id) {
        const existingStripeCustomer = await __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stripe"].customers.retrieve(existingSupabaseCustomer.stripe_customer_id);
        stripeCustomerId = existingStripeCustomer.id;
    } else {
        // If Stripe ID is missing from Supabase, try to retrieve Stripe customer ID by email
        const stripeCustomers = await __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stripe"].customers.list({
            email: email
        });
        stripeCustomerId = stripeCustomers.data.length > 0 ? stripeCustomers.data[0].id : undefined;
    }
    // If still no stripeCustomerId, create a new customer in Stripe
    const stripeIdToInsert = stripeCustomerId ? stripeCustomerId : await createCustomerInStripe(uuid, email);
    if (!stripeIdToInsert) throw new Error('Stripe customer creation failed.');
    if (existingSupabaseCustomer && stripeCustomerId) {
        // If Supabase has a record but doesn't match Stripe, update Supabase record
        if (existingSupabaseCustomer.stripe_customer_id !== stripeCustomerId) {
            const { error: updateError } = await supabaseAdmin.from('customers').update({
                stripe_customer_id: stripeCustomerId
            }).eq('id', uuid);
            if (updateError) throw new Error(`Supabase customer record update failed: ${updateError.message}`);
            console.warn(`Supabase customer record mismatched Stripe ID. Supabase record updated.`);
        }
        // If Supabase has a record and matches Stripe, return Stripe customer ID
        return stripeCustomerId;
    } else {
        console.warn(`Supabase customer record was missing. A new record was created.`);
        // If Supabase has no record, create a new record and return Stripe customer ID
        const upsertedStripeCustomer = await upsertCustomerToSupabase(uuid, stripeIdToInsert);
        if (!upsertedStripeCustomer) throw new Error('Supabase customer record creation failed.');
        return upsertedStripeCustomer;
    }
};
/**
 * Copies the billing details from the payment method to the customer object.
 */ const copyBillingDetailsToCustomer = async (uuid, payment_method)=>{
    //Todo: check this assertion
    const customer = payment_method.customer;
    const { name, phone, address } = payment_method.billing_details;
    if (!name || !phone || !address) return;
    //@ts-ignore
    await __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stripe"].customers.update(customer, {
        name,
        phone,
        address
    });
    const { error: updateError } = await supabaseAdmin.from('users').update({
        billing_address: {
            ...address
        },
        payment_method: {
            ...payment_method[payment_method.type]
        }
    }).eq('id', uuid);
    if (updateError) throw new Error(`Customer update failed: ${updateError.message}`);
};
const manageSubscriptionStatusChange = async (subscriptionId, customerId, createAction = false)=>{
    // Get customer's UUID from mapping table.
    const { data: customerData, error: noCustomerError } = await supabaseAdmin.from('customers').select('id').eq('stripe_customer_id', customerId).single();
    if (noCustomerError) throw new Error(`Customer lookup failed: ${noCustomerError.message}`);
    const { id: uuid } = customerData;
    const subscription = await __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$stripe$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stripe"].subscriptions.retrieve(subscriptionId, {
        expand: [
            'default_payment_method'
        ]
    });
    // Upsert the latest status of the subscription object.
    const subscriptionData = {
        id: subscription.id,
        user_id: uuid,
        metadata: subscription.metadata,
        status: subscription.status,
        price_id: subscription.items.data[0].price.id,
        //TODO check quantity on subscription
        // @ts-ignore
        quantity: subscription.quantity,
        cancel_at_period_end: subscription.cancel_at_period_end,
        cancel_at: subscription.cancel_at ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.cancel_at).toISOString() : null,
        canceled_at: subscription.canceled_at ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.canceled_at).toISOString() : null,
        current_period_start: (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.current_period_start).toISOString(),
        current_period_end: (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.current_period_end).toISOString(),
        created: (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.created).toISOString(),
        ended_at: subscription.ended_at ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.ended_at).toISOString() : null,
        trial_start: subscription.trial_start ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.trial_start).toISOString() : null,
        trial_end: subscription.trial_end ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helpers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toDateTime"])(subscription.trial_end).toISOString() : null
    };
    const { error: upsertError } = await supabaseAdmin.from('subscriptions').upsert([
        subscriptionData
    ]);
    if (upsertError) throw new Error(`Subscription insert/update failed: ${upsertError.message}`);
    console.log(`Inserted/updated subscription [${subscription.id}] for user [${uuid}]`);
    // For a new subscription copy the billing details to the customer object.
    // NOTE: This is a costly operation and should happen at the very end.
    if (createAction && subscription.default_payment_method && uuid) //@ts-ignore
    await copyBillingDetailsToCustomer(uuid, subscription.default_payment_method);
};
;

})()),
"[project]/app/api/sendMessage/route.js [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "GET": ()=>GET,
    "POST": ()=>POST
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/utils/supabase/server.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
async function POST(req) {
    console.log(await req.json(), '___________'); // Add await to log JSON correctly
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
    const { message, recipientId } = await req.json();
    const accessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndidmR1bmxyamVhbWV6bXFnZXp2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcyOTUwOTU4MCwiZXhwIjoyMDQ1MDg1NTgwfQ.HIgiH-r86xkWMcVTCajmj28xBZ8VPcvTW-0Nfrg_Vl4';
    try {
        // Send message to Facebook API
        const fbResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`https://graph.facebook.com/v21.0/110689178427068/messages?access_token=${accessToken}`, {
            recipient: {
                id: recipientId
            },
            messaging_type: 'RESPONSE',
            message: {
                text: message
            }
        });
        // Save message to Supabase database
        const { data, error } = await supabase.from('msgs_messenger').insert([
            {
                text: message,
                recipient_id: recipientId
            }
        ]);
        if (error) throw new Error('Failed to save message to database');
        return new Response(JSON.stringify({
            success: true,
            fbResponse: fbResponse.data,
            dbResponse: data
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error(error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message || 'Internal Server Error'
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}
async function GET(req) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
    const url = new URL(req.url);
    const recipientId = url.searchParams.get('recipientId');
    if (!recipientId) {
        return new Response(JSON.stringify({
            success: false,
            error: 'Recipient ID is required'
        }), {
            status: 400,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
    try {
        const { data, error } = await supabase.from('msgs_messenger').select('*').eq('recipient_id', recipientId);
        if (error) throw error;
        return new Response(JSON.stringify({
            success: true,
            messages: data
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error(error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message || 'Failed to fetch messages'
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}

})()),

};

//# sourceMappingURL=_fe51c3._.js.map