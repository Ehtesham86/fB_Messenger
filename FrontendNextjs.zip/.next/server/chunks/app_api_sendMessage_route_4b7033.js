module.exports = {

"[project]/app/api/sendMessage/route.js [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "POST": ()=>POST
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/utils/supabase/server.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
async function POST(req) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
    // Read the request body only once
    const { message, recipientId } = await req.json();
    console.log({
        message,
        recipientId
    }, '___________'); // Log the message and recipientId
    const accessToken = 'EAAH20PSWGqEBO4NHNau1HQZBR2Mt1Oa2bhzCJsROHIMkODaSCgXK1kDHX9TNo1XMo9ZCzGpSWAi4ZA7Kw4sQWHeerBHQ07VZAuLBr8LyaASZC9b7Yt30bZBvwp242OzXlIUYxElJdIM6uZCMtZCCA4NfKJ24ZB0MwYqrLZA1ltCLKMB3HY2z9N5EjpRZBMsksLycmsb1BmFIIzYEY5NL5QGNZC5joxEZD';
    try {
        // Send message to Facebook API
        const fbResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`https://graph.facebook.com/v21.0/110689178427068/messages?access_token=${accessToken}`, {
            recipient: {
                id: recipientId
            },
            messaging_type: 'RESPONSE',
            message: {
                text: message
            }
        });
        // Save message to Supabase database
        const { data, error } = await supabase.from('msgs_messenger').insert([
            {
                text: message,
                recipient_id: recipientId
            }
        ]);
        if (error) throw new Error('Failed to save message to database');
        return new Response(JSON.stringify({
            success: true,
            fbResponse: fbResponse.data,
            dbResponse: data
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error(error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message || 'Internal Server Error'
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}

})()),

};

//# sourceMappingURL=app_api_sendMessage_route_4b7033.js.map