module.exports = {

"[project]/utils/supabase/server.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "createClient": ()=>createClient
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/@supabase/ssr/dist/index.mjs [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@supabase/ssr/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/headers.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const createClient = ()=>{
    const cookieStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cookies"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createServerClient"])(("TURBOPACK compile-time value", "https://wbvdunlrjeamezmqgezv.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndidmR1bmxyamVhbWV6bXFnZXp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk1MDk1ODAsImV4cCI6MjA0NTA4NTU4MH0.xfYQU71loPgIv2YnWVU63aH0HkG7ha27JsI6e8olTZ4"), // Define a cookies object with methods for interacting with the cookie store and pass it to the client
    {
        cookies: {
            // The get method is used to retrieve a cookie by its name
            get (name) {
                return cookieStore.get(name)?.value;
            },
            // The set method is used to set a cookie with a given name, value, and options
            set (name, value, options) {
                try {
                    cookieStore.set({
                        name,
                        value,
                        ...options
                    });
                } catch (error) {
                // If the set method is called from a Server Component, an error may occur
                // This can be ignored if there is middleware refreshing user sessions
                }
            },
            // The remove method is used to delete a cookie by its name
            remove (name, options) {
                try {
                    cookieStore.set({
                        name,
                        value: '',
                        ...options
                    });
                } catch (error) {
                // If the remove method is called from a Server Component, an error may occur
                // This can be ignored if there is middleware refreshing user sessions
                }
            }
        }
    });
};

})()),
"[project]/app/api/sendMessage/route.js [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "GET": ()=>GET,
    "POST": ()=>POST
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/utils/supabase/server.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
async function POST(req) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
    const { message, recipientId, senderName } = await req.json();
    const accessToken = 'EAAH20PSWGqEBOyzZByO64YZCGdtCPEjz7KEchsZBs3KpoX1D5pcBxiTXvwEZBPXaAwa8jvznkYrvGpEnOnrXUsN6ZAIb8byF2omZAmK0sAVQfKyCLvQFG7mYOEwK3AH8GlDyNMmKYxQdZCsPrZCwlA4SQ0qHY0UKCIshD6Jdgd3OIy1YXPfeJZCEWPQkDeZC2otGx23j3T4IZCHoDhXXT4HqZBE2DZCIZD'; // replace with your actual access token
    try {
        // Check if recipient exists
        const { data: recipientData, error: recipientError } = await supabase.from('recipients').select('id').eq('facebook_id', recipientId).single();
        let recipientIdToUse;
        // If recipient does not exist, create it
        if (recipientError || !recipientData) {
            const { data: newRecipient, error: newRecipientError } = await supabase.from('recipients').insert([
                {
                    recipient_name: senderName,
                    facebook_id: recipientId
                }
            ]).select();
            if (newRecipientError) {
                console.error('Error inserting recipient:', newRecipientError);
                throw new Error(`Failed to create recipient: ${newRecipientError.message}`);
            }
            recipientIdToUse = newRecipient[0].id;
        } else {
            recipientIdToUse = recipientData.id;
        }
        // Send message to Facebook
        const fbResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`https://graph.facebook.com/v21.0/110689178427068/messages?access_token=${accessToken}`, {
            recipient: {
                id: recipientId
            },
            messaging_type: 'RESPONSE',
            message: {
                text: message
            }
        });
        // Check if the Facebook response contains expected data
        const fbRecipientId = fbResponse?.data?.recipient_id;
        const fbMessageId = fbResponse?.data?.message_id;
        if (!fbRecipientId || !fbMessageId) {
            throw new Error('Failed to retrieve recipient_id or message_id from Facebook API response');
        }
        // Insert message into msgs_messender table with the correct recipient_id
        const { data, error } = await supabase.from('msgs_messender').insert([
            {
                text: message,
                recipient_id: recipientIdToUse,
                fb_recipient_id: fbRecipientId,
                fb_message_id: fbMessageId
            }
        ]).select();
        if (error) {
            console.error('Supabase error:', error);
            throw new Error(`Database error: ${error.message}`);
        }
        return new Response(JSON.stringify({
            success: true,
            fbResponse: fbResponse.data,
            dbResponse: data
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error('Error in sending message:', error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}
async function GET(req) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
    try {
        // Fetch messages with recipient_name from the related recipients table
        const { data: messages, error } = await supabase.from('msgs_messender').select(`*,
                recipients:recipient_id (id,recipient_name)`);
        if (error) {
            console.error('Supabase error:', error);
            throw new Error(`Database error: ${error.message}`);
        }
        return new Response(JSON.stringify({
            success: true,
            messages
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error('Error occurred:', error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}

})()),

};

//# sourceMappingURL=_dbb99f._.js.map