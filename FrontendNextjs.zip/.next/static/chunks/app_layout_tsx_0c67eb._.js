(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_0c67eb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_0c67eb._.js",
  "chunks": [
    "static/chunks/node_modules_4c5247._.js",
    "static/chunks/_820dbd._.js",
    "static/chunks/_815d8e._.css",
    "static/chunks/node_modules_fc5325._.js"
  ],
  "source": "dynamic"
});
