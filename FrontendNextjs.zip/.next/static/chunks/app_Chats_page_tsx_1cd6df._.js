(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Chats_page_tsx_1cd6df._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Chats_page_tsx_1cd6df._.js",
  "chunks": [
    "static/chunks/app_Chats_page_tsx_e5f851._.js"
  ],
  "source": "dynamic"
});
