(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_Chat_page_tsx_228cce._.js", {

"[project]/app/Chat/page.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
const Chat = ()=>{
    _s();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedRecipientId, setSelectedRecipientId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [message, setmessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [refresh, setRefresh] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMobileView, setIsMobileView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(window.innerWidth < 768);
    const [recipientId, setRecipientId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('8805839732787665'); // Default recipient ID
    const [response, setResponse] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [senderName, setSenderName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(''); // State for sender's name
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchMessage = async ()=>{
        try {
            const res = await fetch(`https://graph.facebook.com/v21.0/t_1724369945082697/messages?fields=message&access_token=EAAH20PSWGqEBOyzZByO64YZCGdtCPEjz7KEchsZBs3KpoX1D5pcBxiTXvwEZBPXaAwa8jvznkYrvGpEnOnrXUsN6ZAIb8byF2omZAmK0sAVQfKyCLvQFG7mYOEwK3AH8GlDyNMmKYxQdZCsPrZCwlA4SQ0qHY0UKCIshD6Jdgd3OIy1YXPfeJZCEWPQkDeZC2otGx23j3T4IZCHoDhXXT4HqZBE2DZCIZD`); // Call the GET API
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const data = await res.json();
            console.log(data, '_____+');
        } catch (error) {
            setError(error.message);
        }
    };
    // Fetch messages on component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        fetchMessage();
    }, []);
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setResponse(null);
        setError(null);
        try {
            const res = await fetch('/api/sendMessage', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message,
                    recipientId,
                    senderName
                })
            });
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const data = await res.json();
            setResponse(data);
            if (data.success) {
                setmessage(''); // Clear the input after sending
                setSenderName(''); // Clear the sender name input
                fetchMessages(); // Refresh the message list after sending
            }
        } catch (error) {
            setError(error.message);
        }
    };
    // Fetch messages from API
    const fetchMessages = async ()=>{
        try {
            const res = await fetch('/api/sendMessage'); // Call the GET API
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const data = await res.json();
            if (data.success && data.messages) {
                setMessages(data.messages);
            } else {
                setError(data.error || "Failed to fetch messages");
            }
        } catch (error) {
            setError(error.message);
        }
    };
    // Fetch messages on component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        fetchMessages();
        setRefresh(!refresh);
    }, []);
    // Update mobile view state on window resize
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleResize = ()=>setIsMobileView(window.innerWidth < 768);
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    // Group messages by recipient ID
    const groupedMessages = messages.reduce((acc, message)=>{
        const { recipient_id, recipients } = message;
        if (!acc[recipient_id]) {
            acc[recipient_id] = {
                recipient_name: recipients.recipient_name,
                messages: []
            };
        }
        acc[recipient_id].messages.push(message);
        return acc;
    }, {});
    // Handle recipient selection
    const handleRecipientClick = (recipientId)=>{
        setSelectedRecipientId(recipientId);
    };
    // Handle sending a new message
    const handleSendMessage = ()=>{
        if (message.trim() && selectedRecipientId !== null) {
            const messageObj = {
                id: messages.length + 1,
                text: message,
                created_at: new Date().toISOString(),
                recipient_id: selectedRecipientId,
                recipients: {
                    recipient_name: groupedMessages[selectedRecipientId].recipient_name
                }
            };
            setMessages((prevMessages)=>[
                    ...prevMessages,
                    messageObj
                ]);
            setmessage(""); // Clears input after sending
        }
    };
    // Render contacts list
    const renderContactsList = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `w-full ${!isMobileView ? 'md:w-1/3 lg:w-1/4' : ''} bg-gradient-to-t from-black to-slate-500 border-r p-4 overflow-y-auto`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xl text-gray-300 font-serif font-bold mb-4",
                    children: "Contacts"
                }, void 0, false, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 147,
                    columnNumber: 7
                }, this),
                Object.entries(groupedMessages).map(([recipientId, { recipient_name }])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            handleRecipientClick(Number(recipientId));
                            console.log(recipientId, '____');
                            setSenderName(recipient_name);
                        },
                        className: `p-3 w-full text-left rounded-lg flex items-center gap-2 mb-2 ${selectedRecipientId === Number(recipientId) ? "bg-blue-100" : "hover:bg-gray-100"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-semibold font-serif text-black",
                            children: recipient_name
                        }, void 0, false, {
                            fileName: "[project]/app/Chat/page.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this)
                    }, recipientId, false, {
                        fileName: "[project]/app/Chat/page.tsx",
                        lineNumber: 149,
                        columnNumber: 9
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chat/page.tsx",
            lineNumber: 146,
            columnNumber: 5
        }, this);
    // Render chat messages
    const renderChatMessages = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col w-full ${!isMobileView ? 'md:w-2/3 lg:w-3/4' : ''}`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gradient-to-l from-black to-slate-500 text-white p-4 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-semibold",
                            children: groupedMessages[selectedRecipientId].recipient_name
                        }, void 0, false, {
                            fileName: "[project]/app/Chat/page.tsx",
                            lineNumber: 170,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setSelectedRecipientId(null),
                            className: "text-white text-sm bg-gray-800 px-3 py-1 rounded-lg hover:bg-gray-600",
                            children: "Back to Contacts"
                        }, void 0, false, {
                            fileName: "[project]/app/Chat/page.tsx",
                            lineNumber: 173,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 169,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-grow overflow-y-auto p-4 bg-gray-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "space-y-3",
                        children: groupedMessages[selectedRecipientId].messages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: `p-3 rounded-lg shadow-md text-gray-800 max-w-xs ${message.recipient_id === selectedRecipientId ? "bg-blue-200 ml-auto text-right" : "bg-white mr-auto"}`,
                                children: message.text
                            }, message.id, false, {
                                fileName: "[project]/app/Chat/page.tsx",
                                lineNumber: 185,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/Chat/page.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 182,
                    columnNumber: 7
                }, this),
                response && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        color: 'green'
                    },
                    children: "Message sent successfully!"
                }, void 0, false, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 196,
                    columnNumber: 20
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 border-t bg-white flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: message,
                            onChange: (e)=>setmessage(e.target.value),
                            placeholder: "Type a message",
                            className: "flex-grow p-3 rounded-lg border focus:outline-none text-white bg-gradient-to-t from-black to-slate-500 focus:ring focus:ring-blue-200 mr-2"
                        }, void 0, false, {
                            fileName: "[project]/app/Chat/page.tsx",
                            lineNumber: 200,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSubmit,
                            className: "px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-600",
                            children: "Send"
                        }, void 0, false, {
                            fileName: "[project]/app/Chat/page.tsx",
                            lineNumber: 207,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 199,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chat/page.tsx",
            lineNumber: 167,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen bg-gray-200 text-gray-800",
        children: [
            (!isMobileView || selectedRecipientId === null) && renderContactsList(),
            (!isMobileView || selectedRecipientId !== null) && selectedRecipientId !== null && renderChatMessages(),
            isMobileView && selectedRecipientId === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center h-full w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600",
                    children: "Select a contact to start chatting"
                }, void 0, false, {
                    fileName: "[project]/app/Chat/page.tsx",
                    lineNumber: 223,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/Chat/page.tsx",
                lineNumber: 222,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-500 text-center",
                children: error
            }, void 0, false, {
                fileName: "[project]/app/Chat/page.tsx",
                lineNumber: 226,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/Chat/page.tsx",
        lineNumber: 218,
        columnNumber: 5
    }, this);
};
_s(Chat, "WBBWDuT4kx8jxRVUu5LeaTYsPGA=");
_c = Chat;
const __TURBOPACK__default__export__ = Chat;
var _c;
__turbopack_refresh__.register(_c, "Chat");

})()),
"[project]/app/Chat/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),
}]);

//# sourceMappingURL=app_Chat_page_tsx_228cce._.js.map