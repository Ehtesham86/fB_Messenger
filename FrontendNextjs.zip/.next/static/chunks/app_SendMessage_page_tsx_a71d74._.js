(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_SendMessage_page_tsx_a71d74._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_SendMessage_page_tsx_a71d74._.js",
  "chunks": [
    "static/chunks/app_SendMessage_page_tsx_2cbe52._.js"
  ],
  "source": "dynamic"
});
