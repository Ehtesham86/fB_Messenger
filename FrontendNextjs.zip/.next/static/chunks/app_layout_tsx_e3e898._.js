(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_e3e898._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_e3e898._.js",
  "chunks": [
    "static/chunks/node_modules_8a67b6._.js",
    "static/chunks/_0ec43d._.js",
    "static/chunks/_815d8e._.css",
    "static/chunks/node_modules_493d64._.js"
  ],
  "source": "dynamic"
});
