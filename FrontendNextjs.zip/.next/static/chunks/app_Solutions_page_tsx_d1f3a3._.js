(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Solutions_page_tsx_d1f3a3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Solutions_page_tsx_d1f3a3._.js",
  "chunks": [
    "static/chunks/node_modules_54dde8._.js",
    "static/chunks/app_4a2586._.js"
  ],
  "source": "dynamic"
});
