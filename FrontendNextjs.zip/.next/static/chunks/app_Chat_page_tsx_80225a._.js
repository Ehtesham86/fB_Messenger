(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Chat_page_tsx_80225a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Chat_page_tsx_80225a._.js",
  "chunks": [
    "static/chunks/app_Chat_page_tsx_228cce._.js"
  ],
  "source": "dynamic"
});
