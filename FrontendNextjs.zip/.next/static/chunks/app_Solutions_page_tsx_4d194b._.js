(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Solutions_page_tsx_4d194b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Solutions_page_tsx_4d194b._.js",
  "chunks": [
    "static/chunks/app_4a2586._.js",
    "static/chunks/node_modules_50db5a._.js"
  ],
  "source": "dynamic"
});
