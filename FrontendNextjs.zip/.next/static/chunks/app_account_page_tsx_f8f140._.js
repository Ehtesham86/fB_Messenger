(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_account_page_tsx_f8f140._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_account_page_tsx_f8f140._.js",
  "chunks": [
    "static/chunks/_269ad2._.js",
    "static/chunks/components_ui_bc777e._.css"
  ],
  "source": "dynamic"
});
