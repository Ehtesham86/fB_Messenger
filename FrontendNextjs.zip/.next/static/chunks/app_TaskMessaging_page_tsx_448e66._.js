(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_TaskMessaging_page_tsx_448e66._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_TaskMessaging_page_tsx_448e66._.js",
  "chunks": [
    "static/chunks/node_modules_54dde8._.js",
    "static/chunks/app_TaskMessaging_page_tsx_e09227._.js"
  ],
  "source": "dynamic"
});
