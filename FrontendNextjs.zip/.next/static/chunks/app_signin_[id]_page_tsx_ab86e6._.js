(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_signin_[id]_page_tsx_ab86e6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_signin_[id]_page_tsx_ab86e6._.js",
  "chunks": [
    "static/chunks/_76bdc8._.js",
    "static/chunks/components_ui_bc777e._.css"
  ],
  "source": "dynamic"
});
