(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_Chats_0bd6fc._.js", {

"[project]/app/Chats/ModalExample.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io/index.mjs [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
const ModalExample = ()=>{
    _s();
    // Set initial messages state with the provided data
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 21,
            text: "HI am messag",
            created_at: "2024-11-01T11:30:57.675774",
            recipient_id: 2,
            message_id: null,
            fb_message_id: "m_JzDXLZT01CSpXvN5acl4Be0hHGrm3w9jFbJIfOa6PdHtTu0n8TXAAnq1xUB_laKOonZWJ96Rc3kMvkWH2Clcqw",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 2,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 22,
            text: "message again",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 2,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 2,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 23,
            text: "message again222222",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 3,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 3,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 24,
            text: " again222222",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 4,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 4,
                recipient_name: "ali "
            }
        }
    ]);
    // State to track selected user and new message text
    const [selectedUserId, setSelectedUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [newMessage, setNewMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isMobileView, setIsMobileView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(window.innerWidth < 768);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleResize = ()=>setIsMobileView(window.innerWidth < 768);
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    // Extract distinct users from messages
    const users = Array.from(new Set(messages.map((message)=>message.recipient_id))).map((id)=>{
        const message = messages.find((msg)=>msg.recipient_id === id);
        return {
            id,
            recipient_name: message?.recipients.recipient_name || "Unknown"
        };
    });
    // Filter messages for the selected user
    const userMessages = messages.filter((message)=>message.recipient_id === selectedUserId);
    const handleRecipientClick = (userId)=>setSelectedUserId(userId);
    const handleSendMessage = ()=>{
        if (newMessage.trim() && selectedUserId !== null) {
            const newMessageObj = {
                id: messages.length + 1,
                text: newMessage,
                created_at: new Date().toISOString(),
                recipient_id: selectedUserId,
                message_id: null,
                fb_message_id: `m_${Math.random().toString(36).substring(2, 15)}`,
                fb_recipient_id: "generated_fb_recipient_id",
                recipient_name: null,
                recipients: {
                    id: selectedUserId,
                    recipient_name: users.find((user)=>user.id === selectedUserId)?.recipient_name || ""
                }
            };
            setMessages((prevMessages)=>[
                    ...prevMessages,
                    newMessageObj
                ]);
            setNewMessage("");
        }
    };
    const renderContactsList = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `w-full ${!isMobileView ? 'md:w-1/3 lg:w-1/4' : ''} h-auto bg-gradient-to-t from-black to-slate-500 border-r p-4 overflow-y-auto`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xl text-gray-300 font-serif font-bold mb-4",
                    children: "Contacts"
                }, void 0, false, {
                    fileName: "[project]/app/Chats/ModalExample.tsx",
                    lineNumber: 129,
                    columnNumber: 7
                }, this),
                users.map((user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleRecipientClick(user.id),
                        className: `p-3 w-full text-left rounded-lg flex items-center gap-2 mb-2 ${selectedUserId === user.id ? "bg-blue-100" : "hover:bg-gray-500"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-semibold font-serif text-black",
                            children: user.recipient_name
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/ModalExample.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    }, user.id, false, {
                        fileName: "[project]/app/Chats/ModalExample.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chats/ModalExample.tsx",
            lineNumber: 128,
            columnNumber: 5
        }, this);
    const renderChatMessages = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col w-full ${!isMobileView ? 'md:w-2/3 lg:w-3/4' : ''}`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gradient-to-l from-black to-slate-500 text-white p-4 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-semibold",
                            children: users.find((user)=>user.id === selectedUserId)?.recipient_name || "No Recipient Selected"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/ModalExample.tsx",
                            lineNumber: 147,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setSelectedUserId(null),
                            className: "text-white text-sm bg-gray-800 px-3 py-1 rounded-lg hover:bg-gray-600",
                            children: "Back to Contacts"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/ModalExample.tsx",
                            lineNumber: 150,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chats/ModalExample.tsx",
                    lineNumber: 146,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-grow overflow-y-auto p-4 bg-gray-50",
                    children: userMessages.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "space-y-3",
                        children: userMessages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: `p-3 rounded-lg shadow-md text-gray-800 max-w-xs ${message.recipient_id === selectedUserId ? "bg-blue-200 ml-auto text-right" : "bg-white mr-auto"}`,
                                children: message.text
                            }, message.id, false, {
                                fileName: "[project]/app/Chats/ModalExample.tsx",
                                lineNumber: 162,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/Chats/ModalExample.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-gray-600",
                        children: "No messages with this user."
                    }, void 0, false, {
                        fileName: "[project]/app/Chats/ModalExample.tsx",
                        lineNumber: 173,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Chats/ModalExample.tsx",
                    lineNumber: 158,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 border-t bg-white flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: newMessage,
                            onChange: (e)=>setNewMessage(e.target.value),
                            placeholder: "Type a message",
                            className: "flex-grow p-3 rounded-lg border focus:outline-none text-white bg-gradient-to-t from-black to-slate-500 focus:ring focus:ring-blue-200 mr-2"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/ModalExample.tsx",
                            lineNumber: 178,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSendMessage,
                            className: "px-4 py-2 items-center flex gap-2 bg-gray-800 text-white rounded-lg hover:bg-gradient-to-r from-gray-700 via-black to-white",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoIosSend"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/app/Chats/ModalExample.tsx",
                                    lineNumber: 189,
                                    columnNumber: 11
                                }, this),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Send"
                                }, void 0, false, {
                                    fileName: "[project]/app/Chats/ModalExample.tsx",
                                    lineNumber: 189,
                                    columnNumber: 35
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/Chats/ModalExample.tsx",
                            lineNumber: 185,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chats/ModalExample.tsx",
                    lineNumber: 177,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chats/ModalExample.tsx",
            lineNumber: 145,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex bg-gray-200 text-gray-800",
        children: [
            (!isMobileView || selectedUserId === null) && renderContactsList(),
            (!isMobileView || selectedUserId !== null) && selectedUserId !== null && renderChatMessages(),
            isMobileView && selectedUserId === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center h-full w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600",
                    children: "Select a contact to start chatting"
                }, void 0, false, {
                    fileName: "[project]/app/Chats/ModalExample.tsx",
                    lineNumber: 201,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/Chats/ModalExample.tsx",
                lineNumber: 200,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/Chats/ModalExample.tsx",
        lineNumber: 196,
        columnNumber: 5
    }, this);
};
_s(ModalExample, "hV3RCloR4rIzieWv9O+NuWbn4YI=");
_c = ModalExample;
const __TURBOPACK__default__export__ = ModalExample;
var _c;
__turbopack_refresh__.register(_c, "ModalExample");

})()),
"[project]/app/Chats/page.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io/index.mjs [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
const Chat = ()=>{
    _s();
    // Set initial messages state with the provided data
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 21,
            text: "HI am messag",
            created_at: "2024-11-01T11:30:57.675774",
            recipient_id: 2,
            message_id: null,
            fb_message_id: "m_JzDXLZT01CSpXvN5acl4Be0hHGrm3w9jFbJIfOa6PdHtTu0n8TXAAnq1xUB_laKOonZWJ96Rc3kMvkWH2Clcqw",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 2,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 22,
            text: "message again",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 2,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 2,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 23,
            text: "message again222222",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 3,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 3,
                recipient_name: "Ehtesham "
            }
        },
        {
            id: 24,
            text: " again222222",
            created_at: "2024-11-01T11:59:40.758927",
            recipient_id: 4,
            message_id: null,
            fb_message_id: "m__siq1viD0NEpH7Kox8dPSe0hHGrm3w9jFbJIfOa6PdFs7LGW2Ie8EPyxFa4yaxpB8ZFiPZlAJ2BgRwbKTzq9ZA",
            fb_recipient_id: "8805839732787665",
            recipient_name: null,
            recipients: {
                id: 4,
                recipient_name: "ali "
            }
        }
    ]);
    // State to track selected user and new message text
    const [selectedUserId, setSelectedUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [newMessage, setNewMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isMobileView, setIsMobileView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(window.innerWidth < 768);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleResize = ()=>setIsMobileView(window.innerWidth < 768);
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    // Extract distinct users from messages
    const users = Array.from(new Set(messages.map((message)=>message.recipient_id))).map((id)=>{
        const message = messages.find((msg)=>msg.recipient_id === id);
        return {
            id,
            recipient_name: message?.recipients.recipient_name || "Unknown"
        };
    });
    // Filter messages for the selected user
    const userMessages = messages.filter((message)=>message.recipient_id === selectedUserId);
    const handleRecipientClick = (userId)=>setSelectedUserId(userId);
    const handleSendMessage = ()=>{
        if (newMessage.trim() && selectedUserId !== null) {
            const newMessageObj = {
                id: messages.length + 1,
                text: newMessage,
                created_at: new Date().toISOString(),
                recipient_id: selectedUserId,
                message_id: null,
                fb_message_id: `m_${Math.random().toString(36).substring(2, 15)}`,
                fb_recipient_id: "generated_fb_recipient_id",
                recipient_name: null,
                recipients: {
                    id: selectedUserId,
                    recipient_name: users.find((user)=>user.id === selectedUserId)?.recipient_name || ""
                }
            };
            setMessages((prevMessages)=>[
                    ...prevMessages,
                    newMessageObj
                ]);
            setNewMessage("");
        }
    };
    const renderContactsList = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `w-full ${!isMobileView ? 'md:w-1/3 lg:w-1/4' : ''} h-[700px] rounded bg-gradient-to-t from-black to-slate-500 border-r p-4 overflow-y-auto`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xl text-gray-300 font-serif font-bold mb-4",
                    children: "Contacts"
                }, void 0, false, {
                    fileName: "[project]/app/Chats/page.tsx",
                    lineNumber: 129,
                    columnNumber: 7
                }, this),
                users.map((user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleRecipientClick(user.id),
                        className: `p-3 w-full text-left rounded-lg flex items-center gap-2 mb-2 ${selectedUserId === user.id ? "bg-blue-100" : "hover:bg-gray-500"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-semibold font-serif text-black",
                            children: user.recipient_name
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/page.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    }, user.id, false, {
                        fileName: "[project]/app/Chats/page.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chats/page.tsx",
            lineNumber: 128,
            columnNumber: 5
        }, this);
    const renderChatMessages = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col w-full ${!isMobileView ? 'md:w-2/3 lg:w-3/4' : ''}`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gradient-to-l from-black to-slate-500 text-white p-4 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-semibold",
                            children: users.find((user)=>user.id === selectedUserId)?.recipient_name || "No Recipient Selected"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/page.tsx",
                            lineNumber: 147,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setSelectedUserId(null),
                            className: "text-white text-sm bg-gray-800 px-3 py-1 rounded-lg hover:bg-gray-600",
                            children: "Back to Contacts"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/page.tsx",
                            lineNumber: 150,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chats/page.tsx",
                    lineNumber: 146,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-grow overflow-y-auto p-4 bg-gray-50",
                    children: userMessages.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "space-y-3",
                        children: userMessages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: `p-3 rounded-lg shadow-md text-gray-800 max-w-xs ${message.recipient_id === selectedUserId ? "bg-blue-200 ml-auto text-right" : "bg-white mr-auto"}`,
                                children: message.text
                            }, message.id, false, {
                                fileName: "[project]/app/Chats/page.tsx",
                                lineNumber: 162,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/Chats/page.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-gray-600",
                        children: "No messages with this user."
                    }, void 0, false, {
                        fileName: "[project]/app/Chats/page.tsx",
                        lineNumber: 173,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Chats/page.tsx",
                    lineNumber: 158,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 border-t bg-white flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: newMessage,
                            onChange: (e)=>setNewMessage(e.target.value),
                            placeholder: "Type a message",
                            className: "flex-grow p-3 rounded-lg border focus:outline-none text-white bg-gradient-to-t from-black to-slate-500 focus:ring focus:ring-blue-200 mr-2"
                        }, void 0, false, {
                            fileName: "[project]/app/Chats/page.tsx",
                            lineNumber: 178,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSendMessage,
                            className: "px-4 py-2 items-center flex gap-2 bg-gray-800 text-white rounded-lg hover:bg-gradient-to-r from-gray-700 via-black to-white",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoIosSend"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/app/Chats/page.tsx",
                                    lineNumber: 189,
                                    columnNumber: 11
                                }, this),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Send"
                                }, void 0, false, {
                                    fileName: "[project]/app/Chats/page.tsx",
                                    lineNumber: 189,
                                    columnNumber: 35
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/Chats/page.tsx",
                            lineNumber: 185,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/Chats/page.tsx",
                    lineNumber: 177,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/Chats/page.tsx",
            lineNumber: 145,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex bg-gray-200 text-gray-800",
        children: [
            (!isMobileView || selectedUserId === null) && renderContactsList(),
            (!isMobileView || selectedUserId !== null) && selectedUserId !== null && renderChatMessages(),
            isMobileView && selectedUserId === null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center h-full w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: " hidden md:text-gray-600",
                    children: "Select a contact to start chatting"
                }, void 0, false, {
                    fileName: "[project]/app/Chats/page.tsx",
                    lineNumber: 201,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/Chats/page.tsx",
                lineNumber: 200,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/Chats/page.tsx",
        lineNumber: 196,
        columnNumber: 5
    }, this);
};
_s(Chat, "hV3RCloR4rIzieWv9O+NuWbn4YI=");
_c = Chat;
const __TURBOPACK__default__export__ = Chat;
var _c;
__turbopack_refresh__.register(_c, "Chat");

})()),
"[project]/app/Chats/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),
}]);

//# sourceMappingURL=app_Chats_0bd6fc._.js.map