import React from 'react'
import TaskMessaging from '../TaskMessaging/page'

const Solutions = () => {
  return (
    <div>
     <TaskMessaging/> 
    </div>
  )
}

export default Solutions
